# Azure Sentinel Analytics Rules (Split)

This folder contains one ARM template **per analytic rule**, generated from your exported template.

## Where to place in GitHub
Recommended path for a Sentinel repo:
```
/Analytics Rules/<RuleName>.json
```

## How to deploy with GitHub Actions
Your repository already contains a workflow and `azure-sentinel-deploy-*.ps1`. 
Keeping these files under `/Analytics Rules/` allows the workflow to detect and deploy them automatically.

## How to deploy manually (Az CLI)
```
az deployment group create   --resource-group <your-rg>   --template-file "Analytics Rules/<RuleName>.json"   --parameters workspace=<your-workspace-name>
```
